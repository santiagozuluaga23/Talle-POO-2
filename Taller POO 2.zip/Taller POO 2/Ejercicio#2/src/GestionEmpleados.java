import java.util.ArrayList;
import java.util.Scanner;

public class GestionEmpleados {
    private ArrayList<Empleado> empleados;

    public GestionEmpleados() {
        empleados = new ArrayList<>();
    }

    public void añadirEmpleado(Empleado empleado) {
        empleados.add(empleado);
    }

    public void eliminarEmpleado(int idEmpleado) {
        empleados.removeIf(e -> e.getIdEmpleado() == idEmpleado);
    }

    public void mostrarEmpleados() {
        for (Empleado e : empleados) {
            System.out.println(e);
        }
    }

    public static void main(String[] args) {
        GestionEmpleados gestion = new GestionEmpleados();
        Scanner scanner = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("\nBienvenido Sistema de Gestión de Empleados");
            System.out.println("1. Añadir empleado permanente");
            System.out.println("2. Añadir empleado temporal");
            System.out.println("3. Eliminar empleado");
            System.out.println("4. Mostrar empleados");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine(); 

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese el nombre del empleado: ");
                    String nombrePermanente = scanner.nextLine();
                    System.out.print("Ingrese la edad del empleado: ");
                    int edadPermanente = scanner.nextInt();
                    System.out.print("Ingrese el ID del empleado: ");
                    int idPermanente = scanner.nextInt();
                    System.out.print("Ingrese el salario del empleado: ");
                    double salarioPermanente = scanner.nextDouble();
                    scanner.nextLine();
                    System.out.print("Ingrese los beneficios del empleado: ");
                    String beneficios = scanner.nextLine();
                    EmpleadoPermanente empPermanente = new EmpleadoPermanente(nombrePermanente, edadPermanente, idPermanente, salarioPermanente, beneficios);
                    gestion.añadirEmpleado(empPermanente);
                    System.out.println("Empleado permanente añadido con eéxito");
                    break;
                case 2:
                    System.out.print("Ingrese el nombre del empleado: ");
                    String nombreTemporal = scanner.nextLine();
                    System.out.print("Ingrese la edad del empleado: ");
                    int edadTemporal = scanner.nextInt();
                    System.out.print("Ingrese el ID del empleado: ");
                    int idTemporal = scanner.nextInt();
                    System.out.print("Ingrese el salario del empleado: ");
                    double salarioTemporal = scanner.nextDouble();
                    System.out.print("Ingrese la duración del contrato (en meses): ");
                    int duracionContrato = scanner.nextInt();
                    scanner.nextLine(); 
                    EmpleadoTemporal empTemporal = new EmpleadoTemporal(nombreTemporal, edadTemporal, idTemporal, salarioTemporal, duracionContrato);
                    gestion.añadirEmpleado(empTemporal);
                    System.out.println("Empleado temporal añadido con éxito");
                    break;
                case 3:
                    System.out.print("Ingrese el ID del empleado a eliminar: ");
                    int idEliminar = scanner.nextInt();
                    gestion.eliminarEmpleado(idEliminar);
                    System.out.println("Empleado eliminado con éxitto");
                    break;
                case 4:
                    System.out.println("Lista de empleados:");
                    gestion.mostrarEmpleados();
                    break;
                case 5:
                    System.out.println("FIN");
                    break;
                default:
                    System.out.println("Opción erronea, vuelva a intentar");
            }
        } while (opcion != 5);

        scanner.close();
    }
}

