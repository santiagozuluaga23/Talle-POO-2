public class EmpleadoPermanente extends Empleado {
    private String beneficios;

    public EmpleadoPermanente(String nombre, int edad, int idEmpleado, double salario, String beneficios) {
        super(nombre, edad, idEmpleado, salario);
        this.beneficios = beneficios;
    }

    public String getBeneficios() {
        return beneficios;
    }

    public void setBeneficios(String beneficios) {
        this.beneficios = beneficios;
    }

    @Override
    public String toString() {
        return super.toString() + ", Beneficios: " + beneficios;
    }
}
