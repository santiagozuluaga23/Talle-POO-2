import java.util.Scanner;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Inventario inventario = new Inventario();

        while (true) {
            System.out.println("Menu:");
            System.out.println("1. Agregar producto");
            System.out.println("2. Eliminar producto");
            System.out.println("3. Listar productos");
            System.out.println("4. Buscar producto por nombre");
            System.out.println("5. Buscar productos por categoría");
            System.out.println("6. Salir");
            System.out.print("Seleccione una opción: ");
            
            int opcion = scanner.nextInt();
            scanner.nextLine();
            
            switch (opcion) {
                case 1:
                    System.out.println("Agregar producto:");
                    System.out.print("Ingrese ID: ");
                    int id = scanner.nextInt();
                    scanner.nextLine();  
                    System.out.print("Ingrese nombre: ");
                    String nombre = scanner.nextLine();
                    System.out.print("Ingrese precio: ");
                    double precio = scanner.nextDouble();
                    scanner.nextLine();

                    System.out.print("Es un producto específico? (si/no): ");
                    String esEspecifico = scanner.nextLine();

                    if (esEspecifico.equalsIgnoreCase("si")) {
                        System.out.print("Ingrese categoría: ");
                        String categoria = scanner.nextLine();
                        System.out.print("Ingrese marca: ");
                        String marca = scanner.nextLine();
                        ProductoEspecifico productoEspecifico = new ProductoEspecifico(id, nombre, precio, categoria, marca);
                        inventario.agregarProducto(productoEspecifico);
                    } else {
                        Producto producto = new Producto(id, nombre, precio);
                        inventario.agregarProducto(producto);
                    }
                    break;

                case 2:
                    System.out.print("Ingrese el ID del producto a eliminar: ");
                    int idEliminar = scanner.nextInt();
                    scanner.nextLine();  
                    boolean eliminado = inventario.eliminarProducto(idEliminar);
                    if (eliminado) {
                        System.out.println("Producto eliminado con éxiito");
                    } else {
                        System.out.println("Producto no encontrado.");
                    }
                    break;

                case 3:
                    System.out.println("Listado de productos:");
                    inventario.listarProductos();
                    break;

                case 4:
                    System.out.print("Ingrese el nombre del producto a buscar: ");
                    String nombreBuscar = scanner.nextLine();
                    Producto productoEncontrado = inventario.buscarPorNombre(nombreBuscar);
                    if (productoEncontrado != null) {
                        System.out.println("Producto encontrado: " + productoEncontrado);
                    } else {
                        System.out.println("Producto no encontrado.");
                    }
                    break;

                case 5:
                    System.out.print("Ingrese la categoría a buscar: ");
                    String categoriaBuscar = scanner.nextLine();
                    ArrayList<ProductoEspecifico> productosEncontrados = inventario.buscarPorCategoria(categoriaBuscar);
                    if (!productosEncontrados.isEmpty()) {
                        System.out.println("Productos encontrados:");
                        for (ProductoEspecifico producto : productosEncontrados) {
                            System.out.println(producto);
                        }
                    } else {
                        System.out.println("No se encontraron productos en esta categoría");
                    }
                    break;

                case 6:
                    System.out.println("FIN");
                    scanner.close();
                    return;

                default:
                    System.out.println("Opción erronea, vuelva a intenytar");
            }
        }
    }
}
