import java.util.ArrayList;

public class Inventario {
    private ArrayList<Producto> productos;

    public Inventario() {
        productos = new ArrayList<>();
    }

    public void agregarProducto(Producto producto) {
        productos.add(producto);
    }

    public boolean eliminarProducto(int id) {
        for (Producto producto : productos) {
            if (producto.getId() == id) {
                productos.remove(producto);
                return true;
            }
        }
        return false;
    }

    public void listarProductos() {
        for (Producto producto : productos) {
            System.out.println(producto);
        }
    }

    public Producto buscarPorNombre(String nombre) {
        for (Producto producto : productos) {
            if (producto.getNombre().equalsIgnoreCase(nombre)) {
                return producto;
            }
        }
        return null;
    }

    public ArrayList<ProductoEspecifico> buscarPorCategoria(String categoria) {
        ArrayList<ProductoEspecifico> resultados = new ArrayList<>();
        for (Producto producto : productos) {
            if (producto instanceof ProductoEspecifico) {
                ProductoEspecifico prodEsp = (ProductoEspecifico) producto;
                if (prodEsp.getCategoria().equalsIgnoreCase(categoria)) {
                    resultados.add(prodEsp);
                }
            }
        }
        return resultados;
    }
}

