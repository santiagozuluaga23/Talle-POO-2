import java.util.ArrayList;
import java.util.Scanner;

public class GestionCursos {
    private ArrayList<Curso> cursos;

    public GestionCursos() {
        cursos = new ArrayList<>();
    }

    public void agregarCurso(Curso curso) {
        cursos.add(curso);
    }

    public void inscribirEstudianteEnCurso(String codigoCurso, Estudiante estudiante) {
        for (Curso curso : cursos) {
            if (curso.getCodigo().equals(codigoCurso)) {
                curso.inscribirEstudiante(estudiante);
                return;
            }
        }
        System.out.println("Curso no encontrado: " + codigoCurso);
    }

    public void listarEstudiantesInscritos(String codigoCurso) {
        for (Curso curso : cursos) {
            if (curso.getCodigo().equals(codigoCurso)) {
                System.out.println("Estudiantes inscritos en el curso " + curso.getNombre() + ":");
                for (Estudiante estudiante : curso.getListaEstudiantes()) {
                    System.out.println(estudiante);
                }
                return;
            }
        }
        System.out.println("Curso no encontrado: " + codigoCurso);
    }

    public static void main(String[] args) {
        GestionCursos gestion = new GestionCursos();
        Scanner scanner = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("\nSistema de Gestión de Cursos");
            System.out.println("1. Agregar curso");
            System.out.println("2. Inscribir estudiante en curso");
            System.out.println("3. Listar estudiantes inscritos en un curso");
            System.out.println("4. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese el código del curso: ");
                    String codigoCurso = scanner.nextLine();
                    System.out.print("Ingrese el nombre del curso: ");
                    String nombreCurso = scanner.nextLine();
                    Curso curso = new Curso(codigoCurso, nombreCurso);
                    gestion.agregarCurso(curso);
                    System.out.println("Se agregó el curso con éxito");
                    break;
                case 2:
                    System.out.print("Ingrese el código del curso: ");
                    codigoCurso = scanner.nextLine();
                    System.out.print("Ingrese el ID del estudiante: ");
                    int idEstudiante = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Ingrese el nombre del estudiante: ");
                    String nombreEstudiante = scanner.nextLine();
                    System.out.print("Ingrese el email del estudiante: ");
                    String emailEstudiante = scanner.nextLine();
                    Estudiante estudiante = new Estudiante(idEstudiante, nombreEstudiante, emailEstudiante);
                    gestion.inscribirEstudianteEnCurso(codigoCurso, estudiante);
                    System.out.println("Se agregó al estudiandte con éxito");
                    break;
                case 3:
                    System.out.print("Ingrese el código del curso: ");
                    codigoCurso = scanner.nextLine();
                    gestion.listarEstudiantesInscritos(codigoCurso);
                    break;
                case 4:
                    System.out.println("FIN");
                    break;
                default:
                    System.out.println("Opción erronea, vuelva a intentar");
            }
        } while (opcion != 4);

        scanner.close();
    }
}
